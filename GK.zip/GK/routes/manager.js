var express = require('express');
var router = express.Router();
var Dish = require('../models/DishModel')
var Cart = require('../models/CartModel')
var Order = require('../models/OrderModel')

router.get('/revenues', async (req, res) => {
    var now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const orders = await Order.find({ checkin: { $gte: today } }).sort('-checkin').lean().exec()

    Order.aggregate([
        {
            "$group": {
                "_id": {
                    "$dateToString": {
                        "format": "%d-%m-%Y",
                        "date": "$checkin"
                    }
                },
                "sum": { "$sum": '$cart.totalPrice' },
                "count": { "$sum": 1}
            }
        },
        {
            "$project": {
                "date": "$_id",
                "sum": 1,
                "count": 1,
                "_id": 0
            }
        }
    ]).then((revenue) => {
        res.render('management', {orders, revenue})
    })
    // res.render('management', { shift })
})

module.exports = router;