module.exports = function processingOrder(oldOlder) {
    this.order = oldOlder.order || {};
}